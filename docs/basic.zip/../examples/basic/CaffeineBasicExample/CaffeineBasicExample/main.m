//
//  main.m
//  CaffeineBasicExample
//
//  Created by Drew Crawford on 3/7/14.
//  Copyright (c) 2014 DrewCrawfordApps. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DCAAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DCAAppDelegate class]));
    }
}
